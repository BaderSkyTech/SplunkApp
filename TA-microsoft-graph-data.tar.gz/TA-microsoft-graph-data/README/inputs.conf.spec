[graph_data://<name>]
global_account = 
endpoint = 
checkbox =
nested_url = 
delta_checkbox = 
checkpoint_field = 
starting_point = 